import '../../App.css';
import React,{useState,useEffect, Component } from 'react';
import './FAQ.css';

import Navbar from '../navbar';

function FAQ()
{
    return(
    <>
    <Navbar />
    <h1>FAQ</h1>
    </>
  );
}

export default FAQ;