import React from 'react'
import Navbar from '../navbar';
import './css/home.css'

function home() {
  return (
    <div className="outer"> 
      <Navbar/>
     <div className="main">
      <p>hello</p>
    </div>
    </div>
  )
}

export default home
